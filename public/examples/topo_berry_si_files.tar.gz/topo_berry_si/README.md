# Si occupied-state overlaps and FHS slice calculation

QE 7.5 and pw2wannier90 7.5 produced the four-occupied-spatial-band overlap
matrices on full 4x4x4 and 6x6x6 meshes. Silicon is nonmagnetic and has no SOC.

Requires Python 3 and NumPy. The published run used Python 3.12.3 and NumPy 2.4.6.

    python3 -B analyse.py > analyse.out 2> analyse.err
    python3 -B verify.py > verify.out 2> verify.err

source/ holds SCF/NSCF/interface inputs, output logs, XML and native Wannier90
.mmn/.nnkp/.win/.eig files. Numeric data and the native matrix bytes are
unchanged; machine-specific paths in input/output/XML were generalized.
No wavefunction save directory or pseudopotential binary is required for
this postprocessing.

analyse.py reads the complete periodic meshes, verifies matrix blocks and
occupations, computes determinant links, and writes results/*.csv and
results/summary.json. verify.py independently evaluates polar-matrix loops
and a synthetic periodic link field with C=+1. The synthetic field checks
the algorithm's orientation; it is not silicon data.

Every actually sampled fixed-fractional-k3 slice has discrete C=0. The
files save four occupied spatial bands and no conduction bands. A material
gap or Z2 calculation needs additional band data and its own analysis.

SHA256SUMS records every package file except itself.

References:
https://doi.org/10.1143/JPSJ.74.1674
https://wannier90.readthedocs.io/en/latest/user_guide/wannier90/postproc/
