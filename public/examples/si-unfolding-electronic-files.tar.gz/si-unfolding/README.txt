si-unfolding electronic postprocessing example

Python 3; dependencies: NumPy, Matplotlib.
Data extraction checked on Talos using Python 3.12.3 and NumPy 2.4.6. Existing figures are retained; no figure regenerated in this packaging step.

Native energy/weight tables, independent XML, and existing wavefunction/eigenspace checks are included. analyse_unfold.py needs both original tmp/si.save wavefunction sets to recompute those checks; they are not in this postprocessing package.

From the extracted si-unfolding directory:
python3 extract_native_unfold.py
python3 plot_unfold.py

No original QE save directory is included. Input file hashes are in SHA256SUMS.
