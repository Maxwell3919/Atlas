Python 3; NumPy and Matplotlib for plotting.

python3 plane_average.py LOCPOT 2:5 25:28
python3 plot_potential.py

Raw input/output and derived data are included. Existing figures are retained. No POTCAR body or identity audit is included.
