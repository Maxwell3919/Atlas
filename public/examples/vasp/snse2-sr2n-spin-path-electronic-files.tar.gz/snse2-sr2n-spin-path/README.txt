Python 3; NumPy and Matplotlib for plotting.

python3 spin_path.py
python3 plot_spin.py

Raw input/output and derived data are included. Existing figures are retained. No POTCAR body or identity audit is included.
