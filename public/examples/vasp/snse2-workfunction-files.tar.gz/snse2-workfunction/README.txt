SnSe2 work-function teaching calculation. VASP 5.4.4, 8 MPI, 33x33x1 mesh, self-consistent ICHARG=2, LVHAR. Completed 2026-09-22.
POTCAR is not distributed; use your licensed Sn_d/Se datasets matching POTCAR.identity.txt.
Run python3 plane_average.py LOCPOT 1:3 15:17, then python3 workfunction_values.py, then python3 plot_workfunction.py. Only the plotting script requires NumPy and Matplotlib.
The script band-edge counting is specific to even-electron, non-spin-polarized EIGENVAL. Report Phi with the chosen chemical potential for a semiconductor. This run does not establish vacuum/geometry/k-grid convergence.
