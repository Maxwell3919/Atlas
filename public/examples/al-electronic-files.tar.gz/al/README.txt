al electronic postprocessing example

Python 3; dependencies: NumPy, Matplotlib; Plotly for plot_fermi.py.
Data extraction checked on Talos using Python 3.12.3 and NumPy 2.4.6. Existing figures are retained; no figure regenerated in this packaging step.

The original XML is outside the calculation save directories. Only the XML read path in extract_fermi_electronic.py differs from the original parser. J(q) is the defined Gaussian-window geometrical autocorrelation, in eV^-2.

From the extracted al directory:
python3 fermi/extract_fermi_electronic.py
python3 plot_nesting.py
python3 plot_fermi.py
python3 plot_fermi.py --standalone

No original QE save directory is included. Input file hashes are in SHA256SUMS.
